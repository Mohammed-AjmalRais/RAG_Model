import os
import shutil
import uuid

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv

import rag_pipeline

load_dotenv()

app = FastAPI(title="PDF RAG API")

# Allow the Streamlit/React frontend (running on a different port) to call this API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

# In-memory registry of uploaded docs (swap for a DB if you need persistence
# across server restarts beyond what Chroma already keeps)
DOCUMENTS = {}


class AskRequest(BaseModel):
    doc_id: str
    question: str
    top_k: int = 5


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/upload")
async def upload_pdf(file: UploadFile = File(...)):
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are supported.")

    temp_path = os.path.join(UPLOAD_DIR, f"{uuid.uuid4().hex}.pdf")
    with open(temp_path, "wb") as f:
        shutil.copyfileobj(file.file, f)

    try:
        result = rag_pipeline.ingest_pdf(temp_path, file.filename)
    except ValueError as e:
        os.remove(temp_path)
        raise HTTPException(status_code=422, detail=str(e))
    finally:
        file.file.close()

    DOCUMENTS[result["doc_id"]] = result
    return result


@app.get("/documents")
def list_documents():
    return list(DOCUMENTS.values())


@app.post("/ask")
def ask(req: AskRequest):
    if req.doc_id not in DOCUMENTS:
        raise HTTPException(status_code=404, detail="Unknown doc_id. Upload the PDF first.")
    try:
        result = rag_pipeline.ask_question(req.doc_id, req.question, top_k=req.top_k)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return result


@app.delete("/documents/{doc_id}")
def delete_document(doc_id: str):
    if doc_id not in DOCUMENTS:
        raise HTTPException(status_code=404, detail="Unknown doc_id.")
    rag_pipeline.delete_document(doc_id)
    del DOCUMENTS[doc_id]
    return {"deleted": doc_id}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
