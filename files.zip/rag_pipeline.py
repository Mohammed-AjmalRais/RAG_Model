"""
Core RAG pipeline for PDF question answering.

Flow:
    PDF file -> extract text per page (PyMuPDF)
             -> split into overlapping chunks (LangChain splitter)
             -> embed chunks (sentence-transformers, local, free)
             -> store in a persistent ChromaDB collection (one collection per doc)

    Question -> embed -> similarity search top-k chunks
             -> build a grounded prompt
             -> Claude answers using ONLY retrieved context
             -> return answer + source chunks (page numbers) for citation
"""

import os
import re
import uuid
from typing import List, Dict, Any

import fitz  # PyMuPDF
import chromadb
from chromadb.utils import embedding_functions
from langchain_text_splitters import RecursiveCharacterTextSplitter
from anthropic import Anthropic

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
CHROMA_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "chroma_db")
EMBED_MODEL_NAME = "all-MiniLM-L6-v2"   # 384-dim, fast, runs locally/CPU
CHUNK_SIZE = 800          # characters, not tokens (simpler, good enough here)
CHUNK_OVERLAP = 150
TOP_K = 5
CLAUDE_MODEL = "claude-sonnet-4-6"

anthropic_client = Anthropic()  # reads ANTHROPIC_API_KEY from env

chroma_client = chromadb.PersistentClient(path=CHROMA_DIR)

embedding_fn = embedding_functions.SentenceTransformerEmbeddingFunction(
    model_name=EMBED_MODEL_NAME
)

text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=CHUNK_SIZE,
    chunk_overlap=CHUNK_OVERLAP,
    separators=["\n\n", "\n", ". ", " ", ""],
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _clean_text(text: str) -> str:
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def _collection_name(doc_id: str) -> str:
    # Chroma collection names must be simple; prefix keeps things namespaced
    return f"doc_{doc_id}"


# ---------------------------------------------------------------------------
# Ingestion
# ---------------------------------------------------------------------------
def ingest_pdf(file_path: str, original_filename: str) -> Dict[str, Any]:
    """
    Extract, chunk, embed, and store a PDF. Returns metadata about the
    resulting document so the caller can reference it later.
    """
    doc_id = uuid.uuid4().hex[:12]
    pdf = fitz.open(file_path)

    all_chunks: List[str] = []
    all_metadatas: List[Dict[str, Any]] = []

    for page_number in range(len(pdf)):
        page = pdf[page_number]
        raw_text = page.get_text("text")
        cleaned = _clean_text(raw_text)
        if not cleaned:
            continue

        page_chunks = text_splitter.split_text(cleaned)
        for chunk in page_chunks:
            all_chunks.append(chunk)
            all_metadatas.append({
                "page": page_number + 1,   # human-friendly, 1-indexed
                "source": original_filename,
            })

    pdf.close()

    if not all_chunks:
        raise ValueError("No extractable text found in this PDF (it may be scanned/image-only).")

    collection = chroma_client.get_or_create_collection(
        name=_collection_name(doc_id),
        embedding_function=embedding_fn,
        metadata={"source_filename": original_filename},
    )

    ids = [f"{doc_id}_{i}" for i in range(len(all_chunks))]
    # Chroma batches internally, but very large PDFs should be batched here too
    BATCH = 128
    for start in range(0, len(all_chunks), BATCH):
        end = start + BATCH
        collection.add(
            ids=ids[start:end],
            documents=all_chunks[start:end],
            metadatas=all_metadatas[start:end],
        )

    return {
        "doc_id": doc_id,
        "filename": original_filename,
        "num_pages": page_number + 1,
        "num_chunks": len(all_chunks),
    }


# ---------------------------------------------------------------------------
# Retrieval + generation
# ---------------------------------------------------------------------------
def retrieve_chunks(doc_id: str, question: str, top_k: int = TOP_K) -> List[Dict[str, Any]]:
    try:
        collection = chroma_client.get_collection(
            name=_collection_name(doc_id),
            embedding_function=embedding_fn,
        )
    except Exception:
        raise ValueError(f"No document found with id '{doc_id}'. Upload it first.")

    results = collection.query(
        query_texts=[question],
        n_results=top_k,
    )

    chunks = []
    docs = results.get("documents", [[]])[0]
    metas = results.get("metadatas", [[]])[0]
    dists = results.get("distances", [[]])[0]

    for text, meta, dist in zip(docs, metas, dists):
        chunks.append({
            "text": text,
            "page": meta.get("page"),
            "source": meta.get("source"),
            "distance": dist,
        })
    return chunks


def _build_prompt(question: str, chunks: List[Dict[str, Any]]) -> str:
    context_blocks = []
    for i, c in enumerate(chunks, start=1):
        context_blocks.append(f"[Chunk {i} | Page {c['page']}]\n{c['text']}")
    context = "\n\n".join(context_blocks)

    return f"""You are answering questions about a PDF document using ONLY the context excerpts below.

Rules:
- Answer using only information present in the context.
- If the context does not contain the answer, say so clearly — do not guess or use outside knowledge.
- When you use a fact, mention which page it came from, e.g. "(p. 4)".
- Be concise and direct.

Context excerpts:
{context}

Question: {question}

Answer:"""


def ask_question(doc_id: str, question: str, top_k: int = TOP_K) -> Dict[str, Any]:
    chunks = retrieve_chunks(doc_id, question, top_k=top_k)

    if not chunks:
        return {
            "answer": "I couldn't find any relevant content in this document to answer that.",
            "sources": [],
        }

    prompt = _build_prompt(question, chunks)

    response = anthropic_client.messages.create(
        model=CLAUDE_MODEL,
        max_tokens=1000,
        messages=[{"role": "user", "content": prompt}],
    )

    answer_text = "".join(
        block.text for block in response.content if block.type == "text"
    )

    sources = [
        {"page": c["page"], "preview": c["text"][:180] + ("..." if len(c["text"]) > 180 else "")}
        for c in chunks
    ]

    return {"answer": answer_text, "sources": sources}


def delete_document(doc_id: str) -> None:
    try:
        chroma_client.delete_collection(name=_collection_name(doc_id))
    except Exception:
        pass
