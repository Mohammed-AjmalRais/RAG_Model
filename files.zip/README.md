# PDF RAG Chat

Ask questions about any PDF. Upload -> it gets chunked, embedded locally, and stored in
ChromaDB. Questions are answered by Claude, grounded only in the retrieved chunks, with
page-number citations.

## Project structure
```
rag-pdf-app/
├── backend/
│   ├── main.py           # FastAPI app: /upload, /ask, /documents
│   ├── rag_pipeline.py   # extraction, chunking, embedding, retrieval, generation
│   └── requirements.txt
├── frontend/
│   └── app.py            # Streamlit chat UI
└── data/
    ├── uploads/          # raw uploaded PDFs
    └── chroma_db/        # persistent vector store
```

## Setup

1. Create a virtual environment and install dependencies:
   ```bash
   cd backend
   python3 -m venv venv
   source venv/bin/activate        # Windows: venv\Scripts\activate
   pip install -r requirements.txt
   pip install streamlit           # for the frontend
   ```

2. Set your Anthropic API key:
   ```bash
   export ANTHROPIC_API_KEY=your_key_here     # Windows: set ANTHROPIC_API_KEY=...
   ```
   Or create a `.env` file inside `backend/` with:
   ```
   ANTHROPIC_API_KEY=your_key_here
   ```

## Run

**Terminal 1 — backend:**
```bash
cd backend
uvicorn main:app --reload --port 8000
```

**Terminal 2 — frontend:**
```bash
cd frontend
streamlit run app.py
```

Open the Streamlit URL it prints (usually http://localhost:8501), upload a PDF, and start asking questions.

## How it works

1. **Extraction** — `PyMuPDF` pulls text page by page (keeps page numbers for citation).
2. **Chunking** — `RecursiveCharacterTextSplitter` splits each page's text into ~800-char
   chunks with 150-char overlap, so answers aren't cut off mid-sentence.
3. **Embedding** — `sentence-transformers/all-MiniLM-L6-v2` runs locally (no API calls,
   no cost) to embed each chunk into a 384-dim vector.
4. **Storage** — Chunks + embeddings + page metadata go into a per-document ChromaDB
   collection, persisted to disk (`data/chroma_db/`).
5. **Retrieval** — A question is embedded the same way, and the top-k most similar
   chunks are pulled via cosine similarity search.
6. **Generation** — The retrieved chunks are stuffed into a prompt instructing Claude to
   answer *only* from that context and cite page numbers. This is what keeps answers
   grounded instead of hallucinated.

## Extending this for your FYP

- **Evaluation**: build a small set of (question, expected page) pairs and measure
  retrieval hit-rate — good, concrete evaluation section for a report.
- **Multi-document support**: the backend already keys collections by `doc_id`, so you
  can extend `/ask` to search across multiple documents at once.
- **Better chunking**: try semantic chunking (splitting on topic shifts) instead of
  fixed character windows, and compare retrieval quality.
- **Swap embeddings**: try `bge-small-en` or an API-based embedding model (Voyage,
  OpenAI) and compare retrieval accuracy vs. the local MiniLM model — a nice ablation
  for your report.
- **Reranking**: add a cross-encoder reranker (e.g. `bge-reranker-base`) after initial
  retrieval to improve precision on the top-k chunks before they go to Claude.
