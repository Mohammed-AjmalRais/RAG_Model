import requests
import streamlit as st

API_BASE = "http://localhost:8000"

st.set_page_config(page_title="PDF RAG Chat", page_icon="📄", layout="wide")
st.title("📄 Chat with your PDF")

if "doc" not in st.session_state:
    st.session_state.doc = None
if "messages" not in st.session_state:
    st.session_state.messages = []

with st.sidebar:
    st.header("1. Upload a PDF")
    uploaded_file = st.file_uploader("Choose a PDF", type=["pdf"])

    if uploaded_file and st.button("Ingest document", use_container_width=True):
        with st.spinner("Extracting, chunking, and embedding..."):
            files = {"file": (uploaded_file.name, uploaded_file.getvalue(), "application/pdf")}
            resp = requests.post(f"{API_BASE}/upload", files=files)
            if resp.status_code == 200:
                st.session_state.doc = resp.json()
                st.session_state.messages = []
                st.success(f"Indexed {st.session_state.doc['num_chunks']} chunks "
                           f"across {st.session_state.doc['num_pages']} pages.")
            else:
                st.error(resp.json().get("detail", "Upload failed."))

    if st.session_state.doc:
        st.divider()
        st.caption(f"**Active document:** {st.session_state.doc['filename']}")
        st.caption(f"Pages: {st.session_state.doc['num_pages']} | "
                   f"Chunks: {st.session_state.doc['num_chunks']}")
        top_k = st.slider("Chunks to retrieve (top-k)", 1, 10, 5)
    else:
        top_k = 5
        st.info("Upload and ingest a PDF to start chatting.")

st.divider()

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if msg.get("sources"):
            with st.expander("Sources"):
                for s in msg["sources"]:
                    st.markdown(f"**Page {s['page']}** — {s['preview']}")

question = st.chat_input("Ask a question about the PDF...")

if question:
    if not st.session_state.doc:
        st.warning("Upload a PDF first.")
    else:
        st.session_state.messages.append({"role": "user", "content": question})
        with st.chat_message("user"):
            st.markdown(question)

        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                resp = requests.post(f"{API_BASE}/ask", json={
                    "doc_id": st.session_state.doc["doc_id"],
                    "question": question,
                    "top_k": top_k,
                })
                if resp.status_code == 200:
                    data = resp.json()
                    st.markdown(data["answer"])
                    if data.get("sources"):
                        with st.expander("Sources"):
                            for s in data["sources"]:
                                st.markdown(f"**Page {s['page']}** — {s['preview']}")
                    st.session_state.messages.append({
                        "role": "assistant",
                        "content": data["answer"],
                        "sources": data.get("sources", []),
                    })
                else:
                    err = resp.json().get("detail", "Something went wrong.")
                    st.error(err)
                    st.session_state.messages.append({"role": "assistant", "content": f"Error: {err}"})
